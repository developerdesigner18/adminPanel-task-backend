# DDS-Admin-Backend

# Steps to follow for backend:
# 1. npm install
# 2. npm install cross-env
# 3. npm start